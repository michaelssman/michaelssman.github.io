# 小木记账 AI 协作入口

本目录集中维护产品、设计、派工与审核状态。Java 和 Flutter 项目保留原位置与独立 Git 仓库。

## 启动

在 Ghostty 或其他终端执行：

```sh
codex -C "/Users/michael/Documents/app-management"
```

主 Agent 从本目录读取 `AGENTS.md`，按需调用 `.codex/agents/` 中的 `product`、`designer`、`backend`、`flutter`、`reviewer`。默认最多同时运行 3 个子 Agent，模型和推理等级继承主 Agent。

项目配置中的额外可写目录为 `java_demo` 和 `flutter_demo`。进入新会话后使用 `/status` 检查工作目录与权限；使用 `/subagents` 查看子任务。桌面客户端也应从本目录开始新会话，实际可用权限以当前客户端及管理策略为准。

首次在其他机器使用时，先调整 `.codex/config.toml`、`AGENTS.md`、角色文件和本页中的路径。启动时若提示是否信任目录，检查配置后选择信任；不受信任时项目配置可能不生效。

## Figma 设计接入

`designer` 优先使用 Figma。网页登录不等于智能体授权：先在 ChatGPT / Codex 桌面端的 Plugins 中安装 Figma 并完成官方授权，再从本目录开启新会话，检查 Figma 工具和目标文件权限。CLI 会话也必须单独确认可用工具，不能仅凭桌面端已连接推断。

完整安装、CLI 接入和验证步骤见[知识库教程的 Figma 小节](/Users/michael/Documents/michaelssman.github.io/docs/AI/Agent/Java与Flutter多Agent协作配置.md#26-figma)。主 Agent 派工时给出设计文件或节点链接及允许修改的范围；详细设计仍以产品方案批准为前提。权限不足时提供本地 HTML 原型并说明限制，不自动付费或更改分享权限。已有批准的原型继续有效。

## 第一轮提示词

```text
你担任项目负责人，按 AGENTS.md 调度专业 Agent。
本轮先分析「填写一个最不满意的核心流程」。
读取两个项目中相关的实现、现有规范和 docs/current-iteration.md。
请 product 提出问题依据、推荐流程、范围和验收条件，汇总后交我审核。
现在停在产品审核节点；批准后再做原型，原型批准后才实施业务代码。
每个阶段向我提供具体成果，已批准范围内的常规工作自行推进。
```

回复审核时明确对象，例如“批准产品方案中的范围和验收条件，进入原型阶段”或“批准此原型版本，开始开发”。发布时单独说明目标环境和范围。

## 恢复与资料

- 新会话要求主 Agent 先读 `docs/current-iteration.md`，核对两个仓库状态，再从记录的阶段继续；不能仅凭聊天标题推断已经批准。
- 产品、原型、开发、验收的当前状态统一由主 Agent 更新。原型按需放入 `design/<迭代标识>/`；结束后将记录归档到 `docs/iterations/`。
- 此目录当前没有独立 Git 仓库。需要长期版本管理时可单独管理，两个代码仓库的提交与推送仍分别操作。
- 知识库教程：`/Users/michael/Documents/michaelssman.github.io/docs/AI/Agent/Java与Flutter多Agent协作配置.md`。
